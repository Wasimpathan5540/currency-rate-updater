    package com.example.currencyconverter.ui.favourites

    import android.os.Bundle
    import android.view.LayoutInflater
    import android.view.View
    import android.view.ViewGroup
    import android.widget.Toast
    import androidx.fragment.app.Fragment
    import androidx.recyclerview.widget.LinearLayoutManager
    import com.example.currencyconverter.databinding.FragmentFavouritesBinding
    import com.example.currencyconverter.ui.FavouritesAdapter
    import com.google.firebase.auth.FirebaseAuth
    import com.google.firebase.database.*

    class FavouritesFragment : Fragment() {

        private var _binding: FragmentFavouritesBinding? = null
        private val binding get() = _binding!!

        private val auth by lazy { FirebaseAuth.getInstance() }
        private val db by lazy { FirebaseDatabase.getInstance().reference }

        private lateinit var adapter: FavouritesAdapter
        private val items = mutableListOf<String>()

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View {
            _binding = FragmentFavouritesBinding.inflate(inflater, container, false)
            return binding.root
        }

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

            adapter = FavouritesAdapter(items) { pair ->
                // Handle convert click here if needed
            }

            binding.rvFavourites.layoutManager = LinearLayoutManager(requireContext())
            binding.rvFavourites.adapter = adapter

            loadFavourites()
        }

        private fun loadFavourites() {
            val uid = auth.currentUser?.uid ?: return

            val favRef = db.child("users").child(uid).child("favourites")

            favRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<String>()
                    for (child in snapshot.children) {
                        child.key?.let { list.add(it) }
                    }
                    adapter.updateItems(list)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Failed: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }

        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }
    }
