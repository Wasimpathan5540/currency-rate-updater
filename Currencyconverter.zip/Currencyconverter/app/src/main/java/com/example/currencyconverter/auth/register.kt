package com.example.currencyconverter.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.currencyconverter.auth.MainActivity
import com.example.currencyconverter.R
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class register : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editPhone: EditText
    private lateinit var btnSendOTP: Button
    private lateinit var textOTPLabel: TextView
    private lateinit var editOTP: EditText
    private lateinit var btnVerify: Button

    private lateinit var auth: FirebaseAuth
    private var verificationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        // Handle system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        editName = findViewById(R.id.editName)
        editPhone = findViewById(R.id.editPhone)
        btnSendOTP = findViewById(R.id.btnSendOTP)
        textOTPLabel = findViewById(R.id.textOTPLabel)
        editOTP = findViewById(R.id.editOTP)
        btnVerify = findViewById(R.id.btnVerify)

        auth = FirebaseAuth.getInstance()

        // Send OTP button click
        btnSendOTP.setOnClickListener {
            val name = editName.text.toString().trim()
            val phone = editPhone.text.toString().trim()

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Enter name and phone", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            sendOTP(phone)
        }

        // Verify OTP button click
        btnVerify.setOnClickListener {
            val otp = editOTP.text.toString().trim()
            if (otp.isEmpty() || otp.length < 6) {
                Toast.makeText(this, "Enter valid OTP", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            verifyOTP(otp)
        }
    }

    private fun sendOTP(phone: String) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Auto-retrieval or instant verification
                    signInWithCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Toast.makeText(
                        this@register,
                        "Verification Failed: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onCodeSent(
                    vid: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    super.onCodeSent(vid, token)
                    verificationId = vid

                    // Show OTP input fields dynamically
                    textOTPLabel.visibility = View.VISIBLE
                    editOTP.visibility = View.VISIBLE
                    btnVerify.visibility = View.VISIBLE

                    Toast.makeText(
                        this@register,
                        "OTP sent to $phone",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun verifyOTP(otp: String) {
        val credential = PhoneAuthProvider.getCredential(verificationId!!, otp)
        signInWithCredential(credential)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()

                // Navigate to main screen
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            } else {
                Toast.makeText(
                    this,
                    "Error: ${task.exception?.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}