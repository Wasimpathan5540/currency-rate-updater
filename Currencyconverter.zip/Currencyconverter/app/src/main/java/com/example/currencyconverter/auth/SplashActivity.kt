package com.example.currencyconverter.auth

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyconverter.R

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Delay 5 seconds and navigate to mainpage
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, RegisterEmailActivity::class.java))
            finish() // Close splash so user cannot go back
        }, 5000) // 5000 ms = 5 seconds
    }
}