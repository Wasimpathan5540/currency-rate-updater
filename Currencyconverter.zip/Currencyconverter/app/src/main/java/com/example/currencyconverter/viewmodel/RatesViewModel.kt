package com.example.currencyconverter.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RatesViewModel : ViewModel() {

    private lateinit var db: FirebaseDatabase
    private var ratesRef: DatabaseReference? = null
    private var favRef: DatabaseReference? = null
    private var ratesListener: ValueEventListener? = null
    private var favListener: ValueEventListener? = null

    fun startRealtimeListeners(
        uid: String,
        onRatesUpdated: (Map<String, Double>, Long) -> Unit,
        onFavouritesUpdated: (List<String>) -> Unit
    ) {
        db = FirebaseDatabase.getInstance()
        ratesRef = db.getReference("exchangeRates")
        favRef = db.getReference("users/$uid/favourites")

        ratesListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val lastUpdated = snapshot.child("lastUpdated").getValue(Long::class.java) ?: 0L
                val ratesMap = mutableMapOf<String, Double>()
                val ratesSnap = snapshot.child("rates")
                for (child in ratesSnap.children) {
                    val code = child.key ?: continue
                    val value = child.getValue(Double::class.java)
                        ?: child.getValue(Long::class.java)?.toDouble()
                        ?: continue
                    ratesMap[code] = value
                }
                onRatesUpdated(ratesMap, lastUpdated)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("RTDB", "rates canceled: ${error.message}")
            }
        }

        favListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val favs = mutableListOf<String>()
                for (child in snapshot.children) {
                    child.key?.let { favs.add(it) }
                }
                onFavouritesUpdated(favs)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("RTDB", "favs canceled: ${error.message}")
            }
        }

        ratesRef?.addValueEventListener(ratesListener as ValueEventListener)
        favRef?.addValueEventListener(favListener as ValueEventListener)
    }

    override fun onCleared() {
        super.onCleared()
        ratesListener?.let { ratesRef?.removeEventListener(it) }
        favListener?.let { favRef?.removeEventListener(it) }
    }
}