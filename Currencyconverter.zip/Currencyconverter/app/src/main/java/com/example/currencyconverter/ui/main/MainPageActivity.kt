package com.example.currencyconverter.ui.main

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyconverter.auth.LoginActivity
import com.example.currencyconverter.databinding.ActivityMainpageBinding
import com.example.currencyconverter.settings.SettingsActivity
import com.google.firebase.auth.FirebaseAuth
import java.text.DecimalFormat

class MainPageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainpageBinding
    private lateinit var auth: FirebaseAuth

    // Supported currencies
    private val currencies = listOf("USD", "EUR", "INR", "JPY", "GBP")

    // ✅ Corrected: Rates show how many of that currency equals 1 USD
    private val ratesFromUSD = mapOf(
        "USD" to 1.0,
        "EUR" to 0.93,    // 1 USD = 0.93 EUR
        "INR" to 83.0,    // 1 USD = 83.0 INR
        "JPY" to 156.0,   // 1 USD = 156.0 JPY
        "GBP" to 0.81     // 1 USD = 0.81 GBP
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainpageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        setupSpinners()
        setupButtons()
    }

    private fun setupSpinners() {
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)

        binding.spinnerFrom.adapter = adapter
        binding.spinnerTo.adapter = adapter

        // Default selections
        binding.spinnerFrom.setSelection(0) // USD
        binding.spinnerTo.setSelection(2)   // INR
    }

    private fun setupButtons() {

        // Swap Button
        binding.btnSwap.setOnClickListener {
            val fromPos = binding.spinnerFrom.selectedItemPosition
            val toPos = binding.spinnerTo.selectedItemPosition
            binding.spinnerFrom.setSelection(toPos)
            binding.spinnerTo.setSelection(fromPos)
        }

        // Convert Button
        binding.btnConvert.setOnClickListener {
            convertCurrency()
        }

        // Logout Button
        binding.btnLogout.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Settings Button
        binding.btnSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun convertCurrency() {
        val amountText = binding.etAmount.text.toString()
        if (amountText.isEmpty()) {
            Toast.makeText(this, "Enter an amount", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountText.toDoubleOrNull()
        if (amount == null) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val fromCurrency = binding.spinnerFrom.selectedItem.toString()
        val toCurrency = binding.spinnerTo.selectedItem.toString()

        val rate = getConversionRate(fromCurrency, toCurrency)
        val converted = amount * rate
        val formatted = DecimalFormat("#,##0.00").format(converted)

        binding.tvResult.text = "$formatted $toCurrency"
    }

    // ✅ Corrected conversion logic
    private fun getConversionRate(from: String, to: String): Double {
        val fromRate = ratesFromUSD[from] ?: 1.0
        val toRate = ratesFromUSD[to] ?: 1.0

        // Convert `from` → USD → `to`
        val usdValue = 1 / fromRate     // how many USD = 1 fromCurrency
        return usdValue * toRate        // how many toCurrency = that USD amount
    }
}