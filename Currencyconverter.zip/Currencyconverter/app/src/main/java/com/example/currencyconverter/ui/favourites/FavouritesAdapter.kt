package com.example.currencyconverter.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.currencyconverter.R

class FavouritesAdapter(
    private var items: List<String> = emptyList(),
    private val onConvertClick: (currencyCode: String) -> Unit
) : RecyclerView.Adapter<FavouritesAdapter.VH>() {

    private var latestRates: Map<String, Double> = emptyMap()
    private var baseAmount: Double = 1.0

    fun updateRates(rates: Map<String, Double>, baseAmt: Double = 1.0) {
        latestRates = rates
        baseAmount = baseAmt
        notifyDataSetChanged()
    }

    fun updateItems(newItems: List<String>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favourite, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val code = items[position]

        // Format "USD_INR" into "USD → INR"
        val parts = code.split("_")
        val from = parts.getOrNull(0) ?: code
        val to = parts.getOrNull(1) ?: ""

        holder.tvCurrencyCode.text = "$from → $to"

        val rate = latestRates[to]
        val converted = if (rate != null) String.format("%.4f", baseAmount * rate) else "—"
        holder.tvConverted.text = converted

        holder.btnConvert.setOnClickListener {
            onConvertClick(code)
        }
    }

    override fun getItemCount(): Int = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvCurrencyCode: TextView = view.findViewById(R.id.tvCurrencyCode)
        val tvConverted: TextView = view.findViewById(R.id.tvConvertedAmount)
        val btnConvert: Button = view.findViewById(R.id.btnConvert)
    }
}
