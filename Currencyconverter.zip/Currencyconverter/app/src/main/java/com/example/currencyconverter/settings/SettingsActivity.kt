package com.example.currencyconverter.settings

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.currencyconverter.R
import com.example.currencyconverter.auth.LoginActivity
import com.example.currencyconverter.ui.history.ConversionHistoryActivity
import com.example.currencyconverter.ui.profile.ProfileActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var switchDarkMode: Switch
    private lateinit var cardHistory: CardView
    private lateinit var cardFavorites: CardView
    private lateinit var cardRate: CardView
    private lateinit var logoutBtn: Button
    private lateinit var cardProfile: CardView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var imgProfile: ImageView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_settingpage)

        // Handle system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize Views
        switchDarkMode = findViewById(R.id.switch_dark_mode)
        cardHistory = findViewById(R.id.card_history)
        cardFavorites = findViewById(R.id.card_favorites)
        cardRate = findViewById(R.id.card_rate)
        logoutBtn = findViewById(R.id.btn_logout)
        cardProfile = findViewById(R.id.card_profile)
        tvUserName = findViewById(R.id.tv_user_name)
        tvUserEmail = findViewById(R.id.tv_user_email)
        imgProfile = findViewById(R.id.img_profile)

        // 🔹 Load Dummy User Profile (replace with real data later)
        loadDummyProfile()

        // 🔹 Dark Mode Toggle
        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked)
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        // 🔹 Conversion History
        cardHistory.setOnClickListener {
            startActivity(Intent(this, ConversionHistoryActivity::class.java))
        }

        // 🔹 Favorites
        cardFavorites.setOnClickListener {
            startActivity(Intent(this, com.example.currencyconverter.ui.favourites.FavouritesFragment::class.java))

        }

        // 🔹 Rate App
        cardRate.setOnClickListener {
            val appPackageName = packageName
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=$appPackageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")
                    )
                )
            }
        }

        // 🔹 Logout Button
        logoutBtn.setOnClickListener {
            Toast.makeText(this, "Logged out successfully!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // 🔹 Profile Card Click
        cardProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    private fun loadDummyProfile() {
        tvUserName.text = "Guest User"
        tvUserEmail.text = "guest@example.com"
        imgProfile.setImageResource(R.drawable.ic_profile_placeholder) // make sure this exists in drawable
    }
}