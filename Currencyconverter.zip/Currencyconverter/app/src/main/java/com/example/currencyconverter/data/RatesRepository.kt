package com.example.currencyconverter.data

import com.google.firebase.database.*
import kotlin.collections.set

class RatesRepository {
    private val dbRef = FirebaseDatabase.getInstance().getReference("exchangeRates")
    private var listener: ValueEventListener? = null

    init {
        // Keep exchangeRates in sync & cached
        dbRef.keepSynced(true)
    }

    fun observeRates(onRates: (Map<String, Double>) -> Unit) {
        listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val map = mutableMapOf<String, Double>()
                snapshot.children.forEach {
                    val key = it.key ?: return@forEach
                    val vDouble = it.getValue(Double::class.java)
                    val vLong = it.getValue(Long::class.java)
                    val value = vDouble ?: vLong?.toDouble() ?: 0.0
                    map[key] = value
                }
                onRates(map)
            }

            override fun onCancelled(error: DatabaseError) {
                // optionally log error
            }
        }
        dbRef.addValueEventListener(listener as ValueEventListener)
    }

    fun removeListener() {
        listener?.let { dbRef.removeEventListener(it) }
    }
}
