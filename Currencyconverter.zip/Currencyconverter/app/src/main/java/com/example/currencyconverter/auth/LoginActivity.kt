package com.example.currencyconverter.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyconverter.databinding.ActivityLoginPageBinding
import com.example.currencyconverter.ui.main.MainPageActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginPageBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            } else {
                performLogin(email, password)
            }
        }

        binding.registerText.setOnClickListener {
            startActivity(Intent(this, RegisterEmailActivity::class.java))
        }

        binding.checkVerificationButton.setOnClickListener {
            checkEmailVerificationAndProceed()
        }

        // Optional: allow user to request password reset using same email field
        // If your layout doesn't have a "forgotPasswordText" view, you can call this from a menu or other UI.
        binding.forgotPasswordText?.setOnClickListener {
            val email = binding.emailEditText.text.toString().trim()
            if (email.isEmpty()) {
                Toast.makeText(this, "Enter your email to reset password", Toast.LENGTH_SHORT).show()
            } else {
                sendPasswordReset(email)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // If user already logged in and email verified, go to main page
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // reload to get up-to-date verification state
            currentUser.reload().addOnCompleteListener { reloadTask ->
                if (reloadTask.isSuccessful) {
                    if (currentUser.isEmailVerified) {
                        openMainPage()
                    } else {
                        // keep on login screen so user can verify or request resend
                    }
                }
            }
        }
    }

    private fun performLogin(email: String, password: String) {
        // disable button to prevent repeat taps
        binding.loginButton.isEnabled = false
        Toast.makeText(this, "Logging in...", Toast.LENGTH_SHORT).show()

        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            binding.loginButton.isEnabled = true

            if (task.isSuccessful) {
                val user = auth.currentUser
                if (user == null) {
                    Toast.makeText(this, "Login succeeded but user is null", Toast.LENGTH_SHORT).show()
                    return@addOnCompleteListener
                }

                // Always reload to ensure latest emailVerified state
                user.reload().addOnCompleteListener { reloadTask ->
                    if (reloadTask.isSuccessful) {
                        if (user.isEmailVerified) {
                            // Optional: load user profile from Realtime DB before proceeding
                            loadUserProfileAndOpenMain(user.uid)
                        } else {
                            Toast.makeText(this, "Please verify your email first", Toast.LENGTH_SHORT).show()
                            auth.signOut()
                        }
                    } else {
                        Toast.makeText(this, "Failed to verify email state: ${reloadTask.exception?.message}", Toast.LENGTH_SHORT).show()
                        auth.signOut()
                    }
                }
            } else {
                val message = task.exception?.message ?: "Authentication failed"
                Toast.makeText(this, "Login failed: $message", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkEmailVerificationAndProceed() {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "No user is signed in", Toast.LENGTH_SHORT).show()
            return
        }

        user.reload().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                if (user.isEmailVerified) {
                    Toast.makeText(this, "Email verified! Logging in...", Toast.LENGTH_SHORT).show()
                    openMainPage()
                } else {
                    Toast.makeText(this, "Email not verified yet. Check your inbox (or spam).", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Could not check verification status: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendPasswordReset(email: String) {
        binding.loginButton.isEnabled = false
        FirebaseAuth.getInstance().sendPasswordResetEmail(email)
            .addOnCompleteListener {    task ->
                binding.loginButton.isEnabled = true
                if (task.isSuccessful) {
                    Toast.makeText(this, "Password reset email sent. Check your inbox.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Failed to send reset email: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun loadUserProfileAndOpenMain(uid: String) {
        val profileRef = FirebaseDatabase.getInstance().getReference("users/$uid/profile")
        profileRef.get().addOnSuccessListener { snapshot ->
            // You can cache profile data here (SharedPreferences) or pass along via Intent extras.
            // For now we'll just open main page.
            openMainPage()
        }.addOnFailureListener {
            // If profile read fails, still allow login but log a message (toast)
            Toast.makeText(this, "Logged in but failed to load profile: ${it.message}", Toast.LENGTH_SHORT).show()
            openMainPage()
        }
    }

    private fun openMainPage() {
        startActivity(Intent(this, MainPageActivity::class.java))
        finish()
    }
}